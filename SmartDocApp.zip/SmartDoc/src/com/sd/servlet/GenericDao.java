package com.sd.servlet;

public interface GenericDao {

	public String getResponseMessage();
	
	public void setResponseMessage(String message);
	
}
